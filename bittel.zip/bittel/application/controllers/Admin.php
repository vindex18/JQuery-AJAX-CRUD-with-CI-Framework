<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		if($this->session->userdata('adm_id')!="")
			redirect('admin/home');
		else
		{
			$this->session->sess_destroy();
			redirect('login/index');
		}
	}

	public function home()
	{
		if(!empty($this->session->userdata('sess'))){
			$this->load->view('header');
			$this->load->view('emp_table');
			//$this->load->view('footer');
		}
		else
		$this->index();
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login/index');
	}
}

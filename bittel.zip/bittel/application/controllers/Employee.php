<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('employee_model', 'emp_model');
		$this->load->model('authentication', 'auth');
	}

	public function get_all_employees()
	{
		$result = $this->emp_model->get_all_employees();
		//<th scope='col'>#</th>
		$data['emp_list'] = "<table class='table table-condensed table-bordered' id='table_emp'>
							<thead><tr>
                                <th class='shrink' scope='col'>Last Name</th>
                                <th scope='col'>First Name</th>
                                <th scope='col'>Date of Birth</th>
                                <th scope='col'>Gender</th>
                                <th scope='col'>Job Title</th>
                                <th scope='col'>Date Employed</th>
                                <th scope='col'>Actions</th>
                            </tr>
                        </thead>
                        <tbody>";

        if(count($result)>0)
        {
        	//<td>'.$result[$c]['id'].'</td>
			for($c=0;$c<count($result);$c++)
			{
				$data['emp_list'] .= '<tr>
									<td class="lastname shrink">'.$result[$c]['last_name'].'</td>
									<td class="firstname">'.$result[$c]['first_name'].'</td>
									<td>'.date('M d, Y', strtotime($result[$c]['date_of_birth'])).'</td>
									<td>'.$result[$c]['gender'].'</td>
									<td>'.$result[$c]['job_title'].'</td>
									<td>'.date('M d, Y', strtotime($result[$c]['date_employed'])).'</td>
									<td>
									<a href="'.base_url('employee/edit_employee/').$result[$c]['id'].'"  class="btn btn-raised btn-info btn-md edit-emp"><i class="material-icons">edit</i> Update</a>
									<a href="'.base_url('employee/delete_employee/').$result[$c]['id'].'" class="btn btn-raised btn-danger btn-md del-emp"><i class="material-icons">delete_forever</i> Delete</a>
									</td>
									</tr>';
			}

			$data['emp_list'] .= "</tbody></table>";
			$data['numpage'] = ceil($c/10);
		}
		else
		{
			$data['emp_list'] .= "<tr><td colspan='8'><center>No Records Found!</center></td></tr></tbody>";
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($data));	
	}

	public function delete_employee($id = null){
		if(!empty($id))
		{	
			$rec = $this->emp_model->get_employee_rec($id);
			$result = $this->emp_model->delete_employee($id);

			if($result)
				$data = array('status' => 'success', 'type' => 'success', 'title' => 'Success', 'msg' => $rec->first_name." ".$rec->last_name." Deleted Successfully!");
			else
				$data = array('status' => 'failed', 'type' => 'error','title' => 'Success', 'msg' => $rec->first_name." ".$rec->last_name." Added Successfully!");

		}
		else
		{
			$data = array('status' => 'error', 'type' => 'error', 'msg' => "No Item Selected!", 'title' => 'error');
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($data));
	}

	public function update_employee_record($id = null){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('firstname', 'First Name', 'required|max_length[30]');
		$this->form_validation->set_rules('lastname', 'Last Name', 'required|max_length[30]');
		$this->form_validation->set_rules('dateofbirth', 'Date of Birth', 'required|max_length[10]');
		$this->form_validation->set_rules('gender', 'Gender', 'required|max_length[6]');
		$this->form_validation->set_rules('jobtitle', 'Job Title', 'required|max_length[30]');
		$this->form_validation->set_rules('dateofemployment', 'Date of Employment', 'required|max_length[10]');

		if($this->form_validation->run()==false)
		{
			$data = array('status' => 'error', 'type' => 'error', 'title' => 'Error!', 'msg' => validation_errors('<span class="label label-danger">', '</span>'));
		}
		else
		{
			$rec = array('first_name' => strip_tags($this->input->post('firstname')),
						 'last_name' => strip_tags($this->input->post('lastname')),
						 'date_of_birth' => date('Y-m-d', strtotime(strip_tags($this->input->post('dateofbirth')))),
						 'gender' => strip_tags($this->input->post('gender')),
						 'job_title' => strip_tags($this->input->post('jobtitle')),
						 'date_employed' => date('Y-m-d', strtotime(strip_tags($this->input->post('dateofemployment'))))
						 );
			
			$result = $this->emp_model->update_employee_rec($rec, $id);

			//$result = true;
			if($result)
				$data = array('status' => 'success', 'type' => 'success', 'title' => 'Success', 'msg' => strip_tags($this->input->post('firstname'))." ".strip_tags($this->input->post('lastname'))." Updated Successfully!");
			else
				$data = array('status' => 'failed', 'type' => 'error', 'title' => 'Failed', 'msg' => 'Failed to Update '.strip_tags($this->input->post('firstname'))." ".strip_tags($this->input->post('lastname')));
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($data));
	}

	public function edit_employee($id = null){
		if(!empty($id))
		{	
			$rec = $this->emp_model->get_employee_rec($id);

			$data = '<div class="form-error"></div>';
			$data .= form_open(base_url('employee/update_employee_record/'.$id), 'id="recform"');
			$data .= '
			<div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">First Name</label>
   <input type="text" name="firstname" value="'.$rec->first_name.'" maxlength="30" class="form-control camelcase" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required autofocus>
  </div>
        <div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">Last Name</label>
   <input type="text" name="lastname"  value="'.$rec->last_name.'" maxlength="30" class="form-control camelcase" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required>
  </div>
   <div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">Date of Birth</label>
    <input type="text" name="dateofbirth" value="'.date('m/d/Y', strtotime($rec->date_of_birth)).'"  class="form-control datepicker" required/>
  </div><br>
	          <div class="input-group input-group-sm mb-6" style="margin-bottom:-20px;;">
          <p>Gender: &nbsp;</p>';
	             
	          	 $data .= '<div class="radio">
	                  <label style="color:black;">
	                      <input type="radio" name="gender" value="Male"';
	                      $rec->gender == "Male" ? $data .= ' checked>Male&nbsp;
	                  </label>
	              </div>' : $data .= '>Male&nbsp;
	                  </label>
	              </div>';
	         
	          $data .= '<div class="radio">
	                  <label style="color:black;">
	                      <input type="radio" name="gender" value="Female"'; 
	                      $rec->gender == "Female" ? $data .= ' checked>Female
	                  </label>
	              </div>
	              </div>' : $data .= '>Female</label></div></div>';

	          
			  $data .= '     <div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">Job Title</label>
     <input type="text" name="jobtitle" value="'.$rec->job_title.'" maxlength="30" class="form-control camelcase" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required>
  </div>
   <div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">Date of Employment</label>
    <input type="text" name="dateofemployment" value="'.date('m/d/Y', strtotime($rec->date_employed)).'" class="form-control datepicker" required/>
  </div><br>
	          <div class="input-group input-group-sm mb-3">
	              <button id="submit_btn" type="submit" class="btn btn-raised btn-primary">Submit</button>
	          </div>';
	          $data .= form_close();
		}
		else
		{
			$data = array('status' => 'error', 'type' => 'error', 'msg' => "No Item Selected!", 'title' => 'error');
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($data));
	}

	public function add_employee_form(){
		$data = '<div class="form-error"></div>';
		$data .= form_open(base_url('employee/add_new_employee'), 'id="recform"');
		$data .= '
<div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">First Name</label>
   <input type="text" name="firstname" maxlength="30" class="form-control camelcase" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required autofocus>
  </div>
        <div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">Last Name</label>
   <input type="text" name="lastname" maxlength="30" class="form-control camelcase" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required>
  </div>
   <div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">Date of Birth</label>
    <input type="text" name="dateofbirth" class="form-control datepicker" required/>
  </div><br>
          <div class="input-group input-group-sm mb-6" style="margin-bottom:-20px;;">
          <p>Gender: &nbsp;</p>
              <div class="radio">
                  <label style="color:black;">
                      <input type="radio" name="gender" value="Male" checked>
                      Male&nbsp;
                  </label>
              </div>
              <div class="radio">
                  <label style="color:black;">
                      <input type="radio" name="gender" value="Female">
                      Female
                  </label>
              </div>
          </div>
           <div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">Job Title</label>
     <input type="text" name="jobtitle" maxlength="30" class="form-control camelcase" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required>
  </div>
   <div class="form-group bmd-form-group-sm	
" style="margin-bottom:-3px;;">
    <label class="bmd-label-floating">Date of Employment</label>
    <input type="text" name="dateofemployment" class="form-control datepicker" required/>
  </div><br>
          <div class="input-group input-group-sm mb-3">
              <button id="submit_btn" type="submit" class="btn btn-raised btn-primary">Submit</button>
          </div>';
          $data .= form_close();

          $this->output
          	   ->set_content_type('application/json')
          	   ->set_output(json_encode($data));
	}

	public function add_new_employee(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('firstname', 'First Name', 'required|max_length[30]');
		$this->form_validation->set_rules('lastname', 'Last Name', 'required|max_length[30]');
		$this->form_validation->set_rules('dateofbirth', 'Date of Birth', 'required|max_length[10]');
		$this->form_validation->set_rules('gender', 'Gender', 'required|max_length[6]');
		$this->form_validation->set_rules('jobtitle', 'Job Title', 'required|max_length[30]');
		$this->form_validation->set_rules('dateofemployment', 'Date of Employment', 'required|max_length[10]');

		if($this->form_validation->run()==false)
		{
			$data = array('status' => 'error', 'type' => 'error', 'title' => 'Error!', 'msg' => validation_errors('<span class="label label-danger">', '</span>'));
		}
		else
		{
			$rec = array('first_name' => strip_tags($this->input->post('firstname')),
						 'last_name' => strip_tags($this->input->post('lastname')),
						 'date_of_birth' => date('Y-m-d', strtotime(strip_tags($this->input->post('dateofbirth')))),
						 'gender' => strip_tags($this->input->post('gender')),
						 'job_title' => strip_tags($this->input->post('jobtitle')),
						 'date_employed' => date('Y-m-d', strtotime(strip_tags($this->input->post('dateofemployment'))))
						 );
			
			$result = $this->emp_model->add_new_employee($rec);

			//$result = true;
			if($result)
				$data = array('status' => 'success', 'type' => 'success', 'title' => 'Success', 'msg' => strip_tags($this->input->post('firstname'))." ".strip_tags($this->input->post('lastname'))." Added Successfully!");
			else
				$data = array('status' => 'failed', 'type' => 'error', 'title' => 'Failed', 'msg' => 'Failed to Add '.strip_tags($this->input->post('firstname'))." ".strip_tags($this->input->post('lastname')));
		}

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($data));
	}
}
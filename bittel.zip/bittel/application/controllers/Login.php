<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('authentication');
	}

	public function index()
	{
		$this->load->view('login');	
	}

	public function validate()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'required|max_length[30]');
		$this->form_validation->set_rules('password', 'Password', 'required|max_length[30]');

		if($this->form_validation->run()==false)
			$data = array('status' => 'error', 'msg' => validation_errors('<span class="label label-danger">', '</span>'), 'username' => $this->input->post('username'));
		else
		{	
			$result = $this->authentication->validate_credentials(strip_tags($this->input->post('username')), $this->input->post('password')); //strip_tags(
			if($result)
				$data = array('status' => 'success', 'redirect' => base_url('admin/home'));
			else
				$data = array('status' => 'failed', 'msg' => '<span style="color:red;">Incorrect Username and/or Password!');
		}	

		$this->output
			 ->set_content_type('application/json')
			 ->set_output(json_encode($data));
	}
}
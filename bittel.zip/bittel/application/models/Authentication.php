<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function authentication()
	{
		if(empty($this->session->userdata('sess')))
			redirect(base_url());
	}
	public function validate_credentials($username, $password)
	{
		$rec = $this->db->select('*')
						->from('tbl_users')
						->where('username', $username)
						->limit(1)
						->get()
						->row();

		if(!empty($rec))
		{
			if(password_verify($password, $rec->password))
			{
				$sess_data = array('username' => $rec->username, 'first_name' => $rec->first_name, 'last_name' => $rec->last_name, 'id' => $rec->id); 
				$this->session->set_userdata('sess', $sess_data);
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}
}
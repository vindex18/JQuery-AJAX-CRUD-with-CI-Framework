<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function get_all_employees(){
		return $this->db->select('*')
						->from('tbl_employees')
						->get()
						->result_array();
	}

	public function add_new_employee($rec){
		return $this->db->insert('tbl_employees', $rec);
	}

	public function get_employee_rec($id){
		return $this->db->select('*')->from('tbl_employees')->where('id', $id)->get()->row();
	}

	public function delete_employee($id){
		return $this->db->where('id', $id)->delete('tbl_employees');
	}

	public function update_employee_rec($rec, $id){
		return $this->db->set($rec)
						->where('id', $id)
						->update('tbl_employees');
	}
}
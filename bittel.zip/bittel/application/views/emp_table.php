<div class="container-fluid"><br>
<div class="card">
  <div class="card-body">
    <h5 class="card-title">Employee List</h5>
     <p class="card-text">
     <a href="<?php echo base_url('employee/add_employee_form');?>" class="btn btn-raised btn-success" id="add-emp"><i class="material-icons">group_add</i> Add New Employee</a>
     </p>
             <div class="table-responsive">
        <table class="table table-hover table-striped table-condensed" id="table_emp">
        </table>
        
</div>
     </div>
     </div>
      
</div>

<!-- Modal -->

<div id="emp_modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

        </div><!-- End of Body-->
    </div>
  </div>
</div>

<script type="text/javascript">var base_url="<?php echo base_url(); ?>";</script>
<script src="<?php echo base_url('assets/js/jquery.min.js');?>"></script>
<!-- Bootstrap JS 
<script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script> -->


<script src="<?php echo base_url('assets/materialize/js/popper.min.js');?>"></script>
<script src="<?php echo base_url('assets/materialize/js/arrive.min.js');?>"></script>
<script src="<?php echo base_url('assets/materialize/js/bootstrap-material-design.min.js');?>"></script>

<!-- Page Loader -->
<script src="<?php echo base_url('assets/js/pages/pageloader.js');?>"></script>

<!-- Date Picker -->
<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-material-datetimepicker/css/icon.css');?>">
<link rel="stylesheet" href="<?php echo base_url('assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css');?>">
<script src="<?php echo base_url('assets/plugins/bootstrap-material-datetimepicker/js/moment-with-locales.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js');?>"></script>

<!-- Custom JS -->
<script src="<?php echo base_url('assets/js/pages/emp-table.js');?>"></script>  

<!-- SweetAlerts JS -->
<link rel="stylesheet" href="<?php echo base_url('assets/plugins/sweetalert/sweetalert.min.css');?>">
<script src="<?php echo base_url('assets/plugins/sweetalert/sweetalert.min.js');?>"></script>

<!-- JQuery Table Pagination -->

<script src="<?php echo base_url('assets/plugins/jquery-table-pagination/paginathing.js');?>"></script>
<script>
$('input.datepicker').bootstrapMaterialDatePicker({
 weekStart : 0, time: false, clearButton: true, format: 'MM/DD/YYYY'
});
</script>
<style>
table { 
    border-spacing: 0;
    border-collapse: collapse;
}
td {
    padding:0px;
}
</style>
<script>$(document).ready(function() { $('body').bootstrapMaterialDesign(); });</script>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bittel Asia | Employee List</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css');?>">
-->
    <!-- BS Materialize -->
  <link rel="stylesheet" href="<?php echo base_url('assets/materialize/css/bootstrap-material-design.css');?>">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

  <!-- Custom CSS -->

  <link rel="stylesheet" href="<?php echo base_url('assets/css/custom/pageloader.css');?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/custom/homeheader.css');?>">
</head>
<body>
<div class="pageloader"></div>


<nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark" style="color:white;">
  <a class="navbar-brand" href="#">Bittel Asia Inc.</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
     </ul>
      <ul class="navbar-nav mr-2">
    
      <li class="nav-item dropdown">
         <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Hi, <?php echo $this->session->userdata['sess']['first_name']." !"; ?>
         </a>
        <div class="dropdown-menu active">
        <a class="dropdown-item" href="<?php echo base_url('admin/logout');?>">Logout</a>
        </div>
      </li>
    </ul>
    
  </div>
</nav>


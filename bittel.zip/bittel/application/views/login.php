<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bittel Asia Inc.</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 
  <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css');?>">
  -->

  <!-- BS Materialize -->
  <link rel="stylesheet" href="<?php echo base_url('assets/materialize/css/bootstrap-material-design.min.css');?>">
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

   <!-- Custom CSS -->
   <link rel="stylesheet" href="<?php echo base_url('assets/css/custom/pageloader.css');?>">
   <link rel="stylesheet" href="<?php echo base_url('assets/css/custom/homeheader.css');?>">
</head>
<body>

<div class="pageloader"></div>

<nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark" style="color:white;">
  <a class="navbar-brand" href="#">Bittel Asia Inc.</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Who We Are</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          What We Do
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="btn_log_mod" href="#">Login</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>


<div class="bg"></div>
</div>

<!-- Modal -->
<div id="loginModal" class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Bittle Asia Inc.</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
         <?php echo form_open('login/validate', 'id="loginform"'); ?>
          <div class="login-error"></div>
         
          <div class="input-group input-group-sm mb-3">
             <input type="text" name="username" placeholder="Username" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required>
          </div>
        <div class="input-group input-group-sm mb-3">
            <div class="input-group-prepend">
            <span class="input-group-text" id="inputGroup-sizing-sm"></span>
            </div>
            <input type="password" name="password" placeholder="Password" class="form-control" aria-label="Small" aria-describedby="inputGroup-sizing-sm" required>
        </div>
        <div class="checkbox">
            <label>
                <input id="show_password" type="checkbox" value="false"> Show Password
            </label>
        </div><br>
       <div class="input-group" style="text-align:center;">
          <center>
          <button style="background-color:#2E3092;" id="btn_login" class="btn btn-primary btn-md active" role="button" aria-pressed="true">Login</button>
          </center>
       </div>
          <?php echo form_close(); ?>
        </div><!-- End of Body-->
    </div>
  </div>
</div>


</body>
<script type="text/javascript">var base_url="<?php echo base_url(); ?>";</script>
<script src="<?php echo base_url('assets/js/jquery.min.js');?>"></script>
<!-- Bootstrap JS 
<script src="<?php echo base_url('assets/js/bootstrap.min.js');?>"></script> -->
<script src="<?php echo base_url('assets/materialize/js/popper.min.js');?>"></script>
<script src="<?php echo base_url('assets/materialize/js/bootstrap-material-design.min.js');?>"></script>
<script>$(function(){
$('body').bootstrapMaterialDesign();
});</script>
<script src="<?php echo base_url('assets/js/pages/login.js');?>"></script>
<script src="<?php echo base_url('assets/js/pages/pageloader.js');?>"></script>
</html>

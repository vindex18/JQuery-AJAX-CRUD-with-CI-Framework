-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2018 at 12:40 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bittel`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employees`
--

CREATE TABLE `tbl_employees` (
  `id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `job_title` varchar(30) NOT NULL,
  `date_employed` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_employees`
--

INSERT INTO `tbl_employees` (`id`, `first_name`, `last_name`, `date_of_birth`, `gender`, `job_title`, `date_employed`) VALUES
(35, 'Neil Daryl1', 'Sulit', '1997-03-18', 'Male', 'Senior Software Engineer', '2018-05-31'),
(37, 'Wefewf', 'Wefwef', '2018-05-13', 'Male', 'Wefwefwef', '2018-05-13'),
(38, 'Ewcfw', 'We', '2018-05-13', 'Male', 'Wefew', '2018-05-13'),
(39, 'Wefew', 'Wef', '2018-05-13', 'Male', 'Asdfasdfasdf', '2018-05-13'),
(40, 'Ewrew', 'Fwef', '2018-05-13', 'Male', 'Ewfewfewf', '2018-05-13'),
(41, 'Eqwtrywuqtr', 'Ytuyqtruyqt', '2018-05-13', 'Male', 'Qwfqwfqwf', '2018-05-13'),
(42, 'Aefew', 'Fwefewf', '2018-05-13', 'Male', 'Wefcwefc', '2018-05-13'),
(43, 'Wefcew', 'Wefcwef', '2018-05-13', 'Male', 'Wefcwefcwe', '2018-05-13'),
(44, '234234', '23423', '2018-05-13', 'Male', 'Werwerwer', '2018-05-13'),
(45, 'Werwe', 'Wercwer', '2018-05-13', 'Male', 'Wecrwercwer', '2018-05-13'),
(46, 'Wefwecfw', 'Ecwefcwe', '2018-05-13', 'Male', 'Wefcwefcwefcwe', '2018-05-13'),
(47, '235235', '235235', '2018-05-13', 'Male', '23532', '2018-05-13'),
(48, '23532532', '235235', '2018-05-13', 'Male', '23523532', '2018-05-13'),
(49, 'Wetwetvwetvw Wetwet', 'Wetwctwet ', '2018-05-13', 'Male', 'Wtwetwewe Wetwetwet', '2018-05-13'),
(50, 'Werewr', 'Wer', '2018-05-14', 'Male', 'Wer', '2018-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `first_name`, `last_name`, `username`, `password`) VALUES
(1, 'Neil Daryl', 'Sulit', 'neil', '$2y$10$oMJLXRGJ8zS1hBsJcm6UnOEQpzXTpd1XXZ35ZrFq/vT/4cvwJhwhu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_employees`
--
ALTER TABLE `tbl_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_employees`
--
ALTER TABLE `tbl_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

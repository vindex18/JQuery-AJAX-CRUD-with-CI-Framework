$(document).ready(function(){
 get_emp_table();

 $.fn.extend({
    // With every keystroke capitalize first letter of ALL words in the text
    upperFirstAll: function() {
        $(this).keyup(function(event) {
            var box = event.target;
            var txt = $(this).val();
            var start = box.selectionStart;
            var end = box.selectionEnd;

            $(this).val(txt.toLowerCase().replace(/^(.)|(\s|\-)(.)/g,
            function(c) {
                return c.toUpperCase();
            }));
            box.setSelectionRange(start, end);
        });
        return this;
    },

    // With every keystroke capitalize first letter of the FIRST word in the text
    upperFirst: function() {
        $(this).keyup(function(event) {
            var box = event.target;
            var txt = $(this).val();
            var start = box.selectionStart;
            var end = box.selectionEnd;

            $(this).val(txt.toLowerCase().replace(/^(.)/g,
            function(c) {
                return c.toUpperCase();
            }));
            box.setSelectionRange(start, end);
        });
        return this;
    },

    // Converts with every keystroke the hole text to lowercase
    lowerCase: function() {
        $(this).keyup(function(event) {
            var box = event.target;
            var txt = $(this).val();
            var start = box.selectionStart;
            var end = box.selectionEnd;

            $(this).val(txt.toLowerCase());
            box.setSelectionRange(start, end);
        });
        return this;
    },

    // Converts with every keystroke the hole text to uppercase
    upperCase: function() {
        $(this).keyup(function(event) {
            var box = event.target;
            var txt = $(this).val();
            var start = box.selectionStart;
            var end = box.selectionEnd;

            $(this).val(txt.toUpperCase());
            box.setSelectionRange(start, end);
        });
        return this;
    }
    });

	function get_emp_table()
    {
        $.ajax({
            url: base_url + 'employee/get_all_employees',
            type: 'GET',
            dataType: 'JSON',
            success:function(data){
                console.log(data);
                $('#table_emp').replaceWith(data.emp_list);
$('table tbody').paginathing({
  // how many items per page
  perPage: 10, // show item per page
  // // false or number
  limitPagination: false, 
  // enable next / prev buttons
  prevNext: true,
  // enable first / last buttons
  firstLast: false, 
  // custom text for pagination buttons
  prevText: '&laquo;', 
  nextText: '&raquo;', 
  firstText: 'First', 
  lastText: 'Last', 
  // default container class
  containerClass: 'pagination-container', 
  // default ul class
  ulClass: 'pagination', // extend default ul class
  // li class
  liClass: 'page-item', 
  // active class
  activeClass: 'active',
  // disabled class
  disabledClass: 'disabled',
  // class or id (eg: .element or #element). 
  // append the paginator after certain element
  insertAfter: null 
  
});
  //$('ul.pagination a').addClass('page-link')
            },
            error:function(xhr, err){
                console.log(xhr);
                console.log(err);
            }
        });
    }
   
    $(document).on('click', '#add-emp', function(e){
        $('.modal-title').text('Add New Employee');
        e.preventDefault();
        $.ajax({
            url: $(this).attr('href'),
            type: 'GET',
            dataType: 'JSON',
            success:function(data){
                $('.modal-body').replaceWith('<div class="modal-body">'+data+'</div>');
                $('input.datepicker').bootstrapMaterialDatePicker({
                weekStart : 0, time: false, clearButton: true, format: 'MM/DD/YYYY'
                });
                $('#recform .camelcase').upperFirstAll();
                $('body').bootstrapMaterialDesign();
                $('#emp_modal').modal('show');
            },
            error:function(xhr, err){
                console.log(xhr);
                console.log(err);
            }
        });
        
    });

    $(document).on('click', '.edit-emp', function(e){
        $('.modal-title').text('Edit Employee Record');
        e.preventDefault();
        $.ajax({
            url: $(this).attr('href'),
            type: 'GET',
            dataType: 'JSON',
            success:function(data){
                //console.log(data);
                $('.modal-body').replaceWith('<div class="modal-body">'+data+'</div>');
                $('input.datepicker').bootstrapMaterialDatePicker({
                weekStart : 0, time: false, clearButton: true, format: 'MM/DD/YYYY'
                });
                $('#recform .camelcase').upperFirstAll();
                $('body').bootstrapMaterialDesign();
                $('#emp_modal').modal('show');
            },
            error:function(xhr, err){
                console.log(xhr);
                console.log(err);
            }
        });
    });

    $(document).on('click', '.del-emp', function(e){
        e.preventDefault();
        var link = $(this).attr('href');
          swal({
                title: "Warning!",
                text: "Are you sure you want to delete " +$(this).closest("tr").find(".firstname").text()+" "+$(this).closest("tr").find(".lastname").text(),
                type: "warning",
                closeOnEsc: true,
                timer: 5000,
                showCancelButton: true,
                confirmButtonColor: "red",
                confirmButtonText: "Delete",
                closeOnConfirm: true
            }, function () {
                $.ajax({
                        url: link,
                        type: 'GET',
                        dataType: 'JSON',
                        success: function(data){
                            //console.log(data);
                            swal({
                              title: data.title,
                              text: data.msg,
                              closeOnEsc: true,
                              type: data.type,
                              timer: 4000
                            });   
                            get_emp_table(); 
                        },
                        error:function(xhr, err){
                             console.log(xhr);
                             console.log(err);
                        }
                });
            });
    });

    $(document).on('submit', 'form#recform', function(e){
        e.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'JSON',
            success:function(data){
                //console.log(data);
                swal({
                    title: data.title,
                    text: data.msg,
                    closeOnEsc: true,
                    type: data.type,
                    timer: 4000
                });   
                $('#emp_modal').modal('hide');
                get_emp_table(); 
            },
            error:function(xhr, err){
                console.log(xhr);
                console.log(err);
            }
        });
    });
});
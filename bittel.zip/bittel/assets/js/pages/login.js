$(document).ready(function(){

	$(document).on('change', '#show_password', function(e){
		if($('input[name="password"]').prop('type')=="password")
			$('input[name="password"]').prop('type', 'text');
		else
			$('input[name="password"]').prop('type', 'password');
	});

	$(document).on('click', '#btn_log_mod', function(e){
		$('#loginModal').modal('show');
	});

	$('form#loginform').submit(function(e){
		//alert('x');
		e.preventDefault();
		$('.modal-body > .login-error').replaceWith('<div class="login-error"><center><img src="'+base_url+'/assets/res/misc/horizloader.gif" width="25%" height="10%"/></center></div>');
		$.ajax({
			url: base_url + 'login/validate',
			type: 'POST',
			data: $(this).serialize(),
			dataType: 'JSON',
			success:function(data){
				//console.log(data);
				if(data.status=="error")
					$('.login-error').replaceWith('<div class="login-error">'+data.msg+'</div>');
				else if(data.status=="success")
					window.location.href = data.redirect;
				else if(data.status=="failed")
					$('.login-error').replaceWith('<div class="login-error"><small>'+data.msg+'</small></div>');
			},
			error:function(xhr, err){
				console.log(xhr);
				console.log(err);
			}
		});
	});
});
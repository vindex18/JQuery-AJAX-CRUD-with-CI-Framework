
$(window).on('load', function() {
    $(".pageloader").fadeOut("slow");
});
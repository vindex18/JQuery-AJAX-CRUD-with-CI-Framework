Ctrl-C -- exit!
